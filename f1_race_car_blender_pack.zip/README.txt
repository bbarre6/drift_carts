# Stylized F1 Race Car for Blender

Files:
- `f1_race_car.obj` + `f1_race_car.mtl`: importable model with separate mesh parts and material assignments.
- `create_f1_race_car.py`: native Blender generator; run from Blender's Scripting workspace to create editable objects and materials.

## Import OBJ
In Blender: File > Import > Wavefront (.obj), choose `f1_race_car.obj`. Keep the `.mtl` file in the same folder.

## Generate native Blender objects
Open Blender, switch to the Scripting workspace, open `create_f1_race_car.py`, and click Run Script. The car is made from editable parts; front points toward negative Y.

This is a stylized, original F1-inspired model rather than an exact replica of a current team's car. For a more polished result, add subdivision/edge detailing, decals, suspension arms, brake ducts, and team livery.
