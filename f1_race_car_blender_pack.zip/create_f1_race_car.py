# Stylized F1 race car generator for Blender
# Open Blender > Scripting > New, paste this file, then Run Script.
# Car is built from editable mesh objects; dimensions are in Blender units.
import bpy, math
from mathutils import Vector
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)
for datablocks in (bpy.data.meshes, bpy.data.curves, bpy.data.materials):
    pass

def mat(name, color, metallic=0.0, roughness=0.35):
    m=bpy.data.materials.new(name); m.diffuse_color=(*color,1)
    m.use_nodes=True
    bs=m.node_tree.nodes.get("Principled BSDF")
    bs.inputs["Base Color"].default_value=(*color,1)
    bs.inputs["Metallic"].default_value=metallic
    bs.inputs["Roughness"].default_value=roughness
    return m
RED=mat("Racing Red",(0.78,0.018,0.028),0.25)
CARBON=mat("Carbon Fibre",(0.025,0.032,0.04),0.35)
RUBBER=mat("Tire Rubber",(0.008,0.009,0.011),0.0,0.82)
METAL=mat("Wheel Alloy",(0.42,0.46,0.5),0.75)
GOLD=mat("Halo Titanium",(0.95,0.55,0.08),0.65)
GLASS=mat("Cockpit Shadow",(0.006,0.012,0.018),0.2,0.18)
def cube(name, loc, scale, material, bevel=0.0):
    bpy.ops.mesh.primitive_cube_add(size=1, location=loc); o=bpy.context.object
    o.name=name; o.dimensions=scale; bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    o.data.materials.append(material)
    if bevel:
        mod=o.modifiers.new("Soft machined edges","BEVEL"); mod.width=bevel; mod.segments=2
        o.modifiers.new("Weighted corner normals","WEIGHTED_NORMAL")
    return o
def rod(name, a, b, radius, material):
    a,b=Vector(a),Vector(b); d=b-a
    mid=(a+b)/2
    bpy.ops.mesh.primitive_cylinder_add(vertices=12, radius=radius, depth=d.length, location=mid)
    o=bpy.context.object; o.name=name; o.rotation_mode='QUATERNION'; o.rotation_quaternion=d.to_track_quat('Z','Y')
    o.data.materials.append(material); return o
def tire(name, loc, major=0.36, minor=0.16):
    # Torus lies in XY by default; rotate 90 degrees around X so axle is Y.
    bpy.ops.mesh.primitive_torus_add(major_segments=40, minor_segments=12, major_radius=major, minor_radius=minor, location=loc)
    o=bpy.context.object; o.name=name; o.rotation_euler[0]=math.pi/2; o.data.materials.append(RUBBER)
    return o
def tapered(name, sections, material):
    # section = (y, width, bottom_z, top_z); four vertices per section
    vs=[]; fs=[]
    for y,w,bot,top in sections:
        vs += [(-w/2,y,bot),(w/2,y,bot),(w*.38,y,top),(-w*.38,y,top)]
    for i in range(len(sections)-1):
        a=i*4; b=(i+1)*4
        fs += [(a,b,b+1,a+1),(a+2,a+3,b+3,b+2),(a,a+2,b+2,b),(a+1,b+1,b+3,a+3)]
    fs += [(0,1,3,2),tuple(range((len(sections)-1)*4,len(sections)*4))]
    me=bpy.data.meshes.new(name+" Mesh"); me.from_pydata(vs,[],fs); me.materials.append(material); me.update()
    o=bpy.data.objects.new(name,me); bpy.context.collection.objects.link(o)
    bevel=o.modifiers.new("Body edge highlights","BEVEL"); bevel.width=.045; bevel.segments=3
    o.modifiers.new("Body normals","WEIGHTED_NORMAL")
    return o
tapered("Main Monocoque",[(-2.55,.22,.62,.80),(-2.05,.34,.62,.94),(-1.35,.62,.62,1.13),(-.65,.84,.62,1.16),(.15,.92,.62,1.12),(.95,.76,.62,1.00),(1.65,.92,.62,.94),(2.35,.78,.62,.87)],RED)
cube("Front Wing Main",(0,-2.63,.56),(2.05,.20,.10),CARBON,.025)
cube("Front Wing Flap",(0,-2.48,.67),(1.72,.11,.055),RED,.018)
for s in [-1,1]: cube("Front Endplate",(s*1,-2.59,.66),(.07,.30,.26),CARBON,.015)
cube("Rear Wing Main",(0,2.35,1.05),(1.65,.16,.10),CARBON,.025)
cube("Rear Wing Top",(0,2.48,1.43),(1.82,.13,.10),RED,.02)
cube("Rear Pylon",(0,2.18,1.22),(.10,.38,.38),CARBON,.02)
for s in [-1,1]:
    cube("Rear Endplate",(s*.91,2.42,1.25),(.06,.27,.43),CARBON,.015)
    cube("Sidepod",(s*.57,.15,.82),(.43,1.35,.36),RED,.10)
    cube("Sidepod Inlet",(s*.66,-.40,1.015),(.20,.10,.09),GLASS,.015)
cube("Cockpit Opening",(0,-.35,1.13),(.43,.72,.12),GLASS,.07)
cube("Headrest",(0,.35,1.14),(.34,.40,.20),RED,.05)
cube("Engine Cover",(0,.95,1.03),(.43,1.05,.30),RED,.10)
cube("Floor",(0,.05,.53),(1.55,3.55,.12),CARBON,.025)
cube("Diffuser",(0,1.90,.57),(.85,.68,.14),CARBON,.02)
for s in [-1,1]:
    cube("Mirror Stem",(s*.48,-.63,1.17),(.06,.25,.05),CARBON,.015)
    cube("Mirror",(s*.55,-.72,1.20),(.18,.14,.10),RED,.025)
# Wheels, hubs, brake centers
for x in [-.93,.93]:
    for y in [-1.55,1.55]:
        tire("Racing Slick",(x,y,.68))
        # Hub discs face outward on both sides
        for side in [-1,1]:
            bpy.ops.mesh.primitive_cylinder_add(vertices=32, radius=.19, depth=.06, location=(x,y+side*.16,.68), rotation=(math.pi/2,0,0))
            hub=bpy.context.object; hub.name="Alloy Wheel Hub"; hub.data.materials.append(METAL)
            bpy.ops.mesh.primitive_cylinder_add(vertices=24, radius=.075, depth=.075, location=(x,y+side*.20,.68), rotation=(math.pi/2,0,0))
            cap=bpy.context.object; cap.name="Hub Cap"; cap.data.materials.append(CARBON)
# Halo safety structure
rod("Halo Front",(0,-.75,1.12),(0,-.62,1.55),.035,GOLD)
rod("Halo Left",(0,-.62,1.55),(-.48,-.18,1.48),.035,GOLD)
rod("Halo Right",(0,-.62,1.55),(.48,-.18,1.48),.035,GOLD)
rod("Halo Rear Left",(-.48,-.18,1.48),(0,.05,1.46),.035,GOLD)
rod("Halo Rear Right",(0,.05,1.46),(.48,-.18,1.48),.035,GOLD)
# Set origin/view-friendly selection and camera-free clean scene
bpy.ops.object.select_all(action='DESELECT')
body=bpy.data.objects.get("Main Monocoque")
if body:
    body.select_set(True); bpy.context.view_layer.objects.active=body
print("Stylized F1 car created. Front of car points toward negative Y.")
